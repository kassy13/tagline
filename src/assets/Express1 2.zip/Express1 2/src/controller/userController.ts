import {Request, Response} from "express";

export const RegisterUser = async (req: Request, res: Response) => {
    res.send ('respond with a resource');
}