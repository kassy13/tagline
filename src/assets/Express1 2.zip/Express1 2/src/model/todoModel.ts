import { DataTypes, Model, Sequelize } from "sequelize";
import db from "../config/databaseConfig";

export interface TodoAttribute{

    id: string,
    description: string,
    completed: boolean,
   
}

export class TodoInstance extends Model<TodoAttribute> {}

TodoInstance.init(
    {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false
    },

    description: {
        type: DataTypes.STRING,
        allowNull: false
    },

    completed: {
        type: DataTypes.BOOLEAN,
        allowNull: false
    },
    
},
{sequelize: db,  tableName: "todo" }
);